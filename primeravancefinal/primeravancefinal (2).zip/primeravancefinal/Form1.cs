﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace primeravancefinal
{
    public partial class Form1 : Form
    {
        // Define city coordinates
        private Dictionary<string, Point> cityCoordinates = new Dictionary<string, Point>
        {
            { "Indigo Plateau", new Point(52, 106) },
            { "Victory Road", new Point(57, 144) },
            { "Lavender Town", new Point(328, 167) },
            { "Pewter City", new Point(94, 125) },
            { "Viridian Forest", new Point(92,162 ) },
            { "Viridian City", new Point(91, 226) },
            { "Pallet Town", new Point(90, 287) },
            { "Cinnabar Island", new Point(92, 365) },
            { "Mt.Moon", new Point(171, 108) },
            { "Celadon City", new Point(190, 167) },
            { "Fuschia City", new Point(209, 327) },
            { "Cerulean City", new Point(250,107 ) },
            { "Saffron City", new Point(250, 167) },
            { "Vermillion City", new Point(250, 247) },
            { "Bill's house", new Point(289, 69) },
            { "Rock Tunnel", new Point(329, 128) },
            { "SeaFoam Island", new Point(157, 366) },
        };

        private List<(string cityName, Point coordinates)> citiesToDraw = new List<(string cityName, Point coordinates)>();

        // Variable para almacenar la ruta actual
        private List<string> currentPath = null;

        // Initialize city graph
        private Dictionary<string, List<(string city, int distance, int time, int cost)>> cityGraph =
            new Dictionary<string, List<(string city, int distance, int time, int cost)>>();

        // Selected options for transport mode and search criteria
        private string selectedTransportMode = "Auto rentado"; // Default transport mode
        private string selectedSearchCriterion = "Distancia";  // Default search criterion

        // Define a tolerance for proximity checks
        private const int Tolerance = 20;

        public Form1()
        {
            InitializeComponent();

            // MouseClick event for the PictureBox
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseClick);
            this.pictureBox1.Paint += new PaintEventHandler(this.pictureBox1_Paint);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Initialize graph and cities
            InitializeCityGraph(); // Initialize graph 
            InitializeDefaultCities(); // Initialize and draw default cities

            // Populate ComboBoxes
            PopulateComboBox3();
            PopulateComboBox4();
            PopulateRouteComboBoxes();
        }

        // Initialize the graph with default values
        private void InitializeCityGraph()
        {
            cityGraph.Clear(); // Clear any existing graph data

            // Ensure every city has an entry in cityGraph
            foreach (var city in cityCoordinates.Keys)
            {
                if (!cityGraph.ContainsKey(city))
                {
                    cityGraph[city] = new List<(string city, int distance, int time, int cost)>();
                }
            }

            // Manually add connections between default cities
            // Example connections (you can adjust these or add more):

            AddRoute("Pallet Town", "Viridian City", 50, 60, 200, 70, 150);
            AddRoute("Viridian City", "Pewter City", 80, 90, 320, 100, 240);
            AddRoute("Pewter City", "Cerulean City", 70, 80, 280, 90, 210);
            AddRoute("Cerulean City", "Lavender Town", 60, 70, 240, 80, 180);
            AddRoute("Lavender Town", "Saffron City", 40, 50, 160, 60, 120);
            AddRoute("Saffron City", "Celadon City", 30, 40, 120, 50, 90);
            AddRoute("Celadon City", "Fuschia City", 90, 100, 360, 110, 270);
            AddRoute("Fuschia City", "Cinnabar Island", 110, 120, 440, 130, 330);
            AddRoute("Cinnabar Island", "Pallet Town", 120, 130, 480, 140, 360);

            // Add more connections as needed
        }

        // Método para agregar una ruta al grafo
        private void AddRoute(string startCity, string endCity, int distance, int autoTime, int autoCost, int publicTime, int publicCost)
        {
            if (!cityGraph.ContainsKey(startCity))
            {
                cityGraph[startCity] = new List<(string city, int distance, int time, int cost)>();
            }

            if (!cityGraph.ContainsKey(endCity))
            {
                cityGraph[endCity] = new List<(string city, int distance, int time, int cost)>();
            }

            // Añadir conexión bidireccional
            cityGraph[startCity].Add((endCity, distance, autoTime, autoCost));
            cityGraph[endCity].Add((startCity, distance, publicTime, publicCost));
        }

        // Dijkstra's Algorithm for finding the shortest path
        private (List<string> path, int distance) FindShortestPath(string startCity, string endCity)
        {
            // Priority queue for Dijkstra's Algorithm
            var priorityQueue = new SortedSet<(int cost, string city)>();
            var distances = new Dictionary<string, int>();
            var previousCities = new Dictionary<string, string>();

            // Initialize distances to infinity
            foreach (var city in cityGraph.Keys)
            {
                distances[city] = int.MaxValue;
            }

            distances[startCity] = 0;
            priorityQueue.Add((0, startCity));

            while (priorityQueue.Count > 0)
            {
                var current = priorityQueue.Min;
                var currentCost = current.cost;
                var currentCity = current.city;

                priorityQueue.Remove(priorityQueue.Min);

                if (currentCity == endCity)
                {
                    break; // Destination reached
                }

                foreach (var neighborTuple in cityGraph[currentCity])
                {
                    var neighbor = neighborTuple.city;
                    var distance = neighborTuple.distance;
                    var time = neighborTuple.time;
                    var cost = neighborTuple.cost;

                    // Decide which parameter to optimize
                    int newCost = currentCost;
                    if (selectedSearchCriterion == "Distancia")
                    {
                        newCost += distance;
                    }
                    else if (selectedSearchCriterion == "Tiempo")
                    {
                        newCost += time;
                    }
                    else if (selectedSearchCriterion == "Costo")
                    {
                        newCost += cost;
                    }

                    if (newCost < distances[neighbor])
                    {
                        priorityQueue.Remove((distances[neighbor], neighbor)); // Remove old value
                        distances[neighbor] = newCost;
                        previousCities[neighbor] = currentCity;
                        priorityQueue.Add((newCost, neighbor));
                    }
                }
            }

            // Reconstruct the path
            var path = new List<string>();
            string currentPathCity = endCity;

            while (currentPathCity != null && previousCities.ContainsKey(currentPathCity))
            {
                path.Add(currentPathCity);
                currentPathCity = previousCities[currentPathCity];
            }

            if (currentPathCity == startCity)
            {
                path.Add(startCity);
            }
            else
            {
                // No path found
                return (new List<string>(), int.MaxValue);
            }

            path.Reverse();

            return (path, distances[endCity]);
        }
        // end Dijkstra 

        // PictureBox Paint event handler
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            // Use Graphics object from the PaintEventArgs
            Graphics g = e.Graphics;

            // Dibuja las conexiones entre las ciudades
            DrawCityConnections(g);

            // Dibuja la ruta si existe
            if (currentPath != null && currentPath.Count > 1)
            {
                Pen pen = new Pen(Color.White, 10); // Color y grosor de la línea

                for (int i = 0; i < currentPath.Count - 1; i++)
                {
                    string cityA = currentPath[i];
                    string cityB = currentPath[i + 1];

                    Point pointA = cityCoordinates[cityA];
                    Point pointB = cityCoordinates[cityB];

                    g.DrawLine(pen, pointA, pointB);
                }
            }

            // Draw each city in the list
            foreach (var city in citiesToDraw)
            {
                DrawCity(g, city.cityName, city.coordinates);
            }
        }

        // Método para dibujar las conexiones entre ciudades
        private void DrawCityConnections(Graphics g)
        {
            Pen pen = new Pen(Color.White, 10); // Color y grosor de las líneas de conexión
            HashSet<(string, string)> drawnEdges = new HashSet<(string, string)>();

            foreach (var city in cityGraph)
            {
                string cityA = city.Key;
                Point pointA = cityCoordinates[cityA];

                foreach (var connection in city.Value)
                {
                    string cityB = connection.city;

                    // Evitar dibujar líneas duplicadas
                    if (!drawnEdges.Contains((cityB, cityA)))
                    {
                        Point pointB = cityCoordinates[cityB];
                        g.DrawLine(pen, pointA, pointB);

                        drawnEdges.Add((cityA, cityB));
                    }
                }
            }
        }

        // Draw city on map
        private void DrawCity(Graphics g, string cityName, Point coordinates)
        {
            // Draw a circle to represent the city
            Brush brush = Brushes.Red; // Color for city dots
            int radius = 8; // Size of the city dot

            // Draw the dot
            g.FillEllipse(brush, coordinates.X - radius / 2, coordinates.Y - radius / 2, radius, radius);

            // Draw the city name
            Font font = new Font("Arial", 6, FontStyle.Bold);
            Brush textBrush = Brushes.Black;
            g.DrawString(cityName, font, textBrush, coordinates.X + 5, coordinates.Y - 8);
        }

        private void InitializeDefaultCities()
        {
            foreach (var city in cityCoordinates)
            {
                string cityName = city.Key;
                Point coordinates = city.Value;

                // Add the city to the list of cities to draw
                citiesToDraw.Add((cityName, coordinates));
            }

            // Refresh the PictureBox to trigger the Paint event
            pictureBox1.Invalidate();
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            // Check which mouse button was clicked
            if (e.Button == MouseButtons.Left)
            {
                PlaceMarker(e.Location, "Start");
            }
            else if (e.Button == MouseButtons.Right)
            {
                PlaceMarker(e.Location, "Destination");
            }
        }

        private void PlaceMarker(Point location, string markerType)
        {
            PictureBox marker = new PictureBox
            {
                Size = new Size(10, 10),
                BackColor = markerType == "Start" ? Color.Green : Color.Red,
                Location = new Point(location.X - 5, location.Y - 5), // Center  marker
                BorderStyle = BorderStyle.FixedSingle
            };

            // Add the marker to PictureBox
            pictureBox1.Controls.Add(marker);

            // Checks if the marker is near a city
            string nearestCity = GetNearestCity(location);
            if (nearestCity != null)
            {
                MessageBox.Show($"{markerType} marker placed near {nearestCity} at ({location.X}, {location.Y})", "Marker Added");
            }
            else
            {
                MessageBox.Show($"{markerType} marker placed at ({location.X}, {location.Y}) with no nearby city", "Marker Added");
            }
        }

        // GetNearestCity method
        private string GetNearestCity(Point markerLocation)
        {
            foreach (var city in cityCoordinates)
            {
                double distance = Math.Sqrt(
                    Math.Pow(markerLocation.X - city.Value.X, 2) +
                    Math.Pow(markerLocation.Y - city.Value.Y, 2)
                );

                if (distance <= Tolerance)
                {
                    return city.Key; // Return city name
                }
            }

            return null; // No city found within tolerance
        }

        // Alta de ciudad (Button 4)
        private void button4_Click(object sender, EventArgs e)
        {
            // Get input values
            string cityName = textBox7.Text.Trim();
            int xCoordinate = (int)numericUpDown1.Value;
            int yCoordinate = (int)numericUpDown2.Value;

            // Validate inputs
            if (string.IsNullOrEmpty(cityName))
            {
                MessageBox.Show("El nombre de la ciudad no puede estar vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (cityCoordinates.ContainsKey(cityName))
            {
                MessageBox.Show("El nombre de la ciudad ya existe. Por favor, elija un nombre diferente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Add the city to the dictionary
            cityCoordinates.Add(cityName, new Point(xCoordinate, yCoordinate));

            // Add the city to the list of cities to draw
            citiesToDraw.Add((cityName, new Point(xCoordinate, yCoordinate)));

            // Add the city to the graph with an empty list of connections
            if (!cityGraph.ContainsKey(cityName))
            {
                cityGraph[cityName] = new List<(string city, int distance, int time, int cost)>();
            }

            // Refresh the PictureBox
            pictureBox1.Invalidate();

            // Provide feedback to the user
            MessageBox.Show($"¡Ciudad '{cityName}' agregada exitosamente en las coordenadas ({xCoordinate}, {yCoordinate})!", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Clear the input fields after adding
            textBox7.Clear();
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;

            // Populate ComboBoxes
            PopulateComboBox3();
            PopulateComboBox4();
            PopulateRouteComboBoxes();
        }

        // Baja de ciudad (Button 5)
        private void button5_Click(object sender, EventArgs e)
        {
            // Get the city name from the input field
            string cityName = textBox7.Text.Trim();

            // Validate input
            if (string.IsNullOrEmpty(cityName))
            {
                MessageBox.Show("Por favor, ingrese el nombre de la ciudad a eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check if the city exists
            if (!cityCoordinates.ContainsKey(cityName))
            {
                MessageBox.Show($"La ciudad '{cityName}' no existe.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Remove the city from the dictionary
            cityCoordinates.Remove(cityName);

            // Remove from citiesToDraw
            citiesToDraw.RemoveAll(c => c.cityName == cityName);

            // Remove from cityGraph
            cityGraph.Remove(cityName);
            foreach (var connections in cityGraph.Values)
            {
                connections.RemoveAll(c => c.city == cityName);
            }

            // Refresh the PictureBox
            pictureBox1.Invalidate();

            // Prints info to user
            MessageBox.Show($"La ciudad '{cityName}' ha sido eliminada exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Clear the input field
            textBox7.Clear();

            // Populate ComboBoxes
            PopulateComboBox3();
            PopulateComboBox4();
            PopulateRouteComboBoxes();

            // Limpia la ruta actual si la ciudad eliminada está en ella
            if (currentPath != null && currentPath.Contains(cityName))
            {
                currentPath = null;
                pictureBox1.Invalidate();
            }
        }

        // Cambio de datos de ciudad (Button 6)
        private void button6_Click(object sender, EventArgs e)
        {
            // Get input values
            string oldCityName = textBox7.Text.Trim();
            string newCityName = textBox11.Text.Trim();
            int newXCoordinate = (int)numericUpDown1.Value;
            int newYCoordinate = (int)numericUpDown2.Value;

            // Validate input
            if (string.IsNullOrEmpty(oldCityName))
            {
                MessageBox.Show("Por favor, ingrese el nombre actual de la ciudad a modificar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!cityCoordinates.ContainsKey(oldCityName))
            {
                MessageBox.Show($"La ciudad '{oldCityName}' no existe.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check if the new name conflicts with an existing city
            if (!string.IsNullOrEmpty(newCityName) && oldCityName != newCityName && cityCoordinates.ContainsKey(newCityName))
            {
                MessageBox.Show($"El nombre de la ciudad '{newCityName}' ya existe. Por favor, elija un nombre diferente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Update city coordinates
            Point updatedCoordinates = new Point(newXCoordinate, newYCoordinate);

            // If the city name changes, update the dictionary key
            if (!string.IsNullOrEmpty(newCityName) && oldCityName != newCityName)
            {
                // Remove the old entry and add the updated one
                cityCoordinates.Remove(oldCityName);
                cityCoordinates[newCityName] = updatedCoordinates;

                // Update in citiesToDraw
                var cityToUpdate = citiesToDraw.FirstOrDefault(c => c.cityName == oldCityName);
                if (cityToUpdate != default)
                {
                    citiesToDraw.Remove(cityToUpdate);
                    citiesToDraw.Add((newCityName, updatedCoordinates));
                }

                // Update in cityGraph
                if (cityGraph.ContainsKey(oldCityName))
                {
                    var connections = cityGraph[oldCityName];
                    cityGraph.Remove(oldCityName);
                    cityGraph[newCityName] = connections;
                }

                foreach (var connections in cityGraph.Values)
                {
                    for (int i = 0; i < connections.Count; i++)
                    {
                        if (connections[i].city == oldCityName)
                        {
                            connections[i] = (newCityName, connections[i].distance, connections[i].time, connections[i].cost);
                        }
                    }
                }
            }
            else
            {
                // Update the coordinates in place
                cityCoordinates[oldCityName] = updatedCoordinates;

                // Update in citiesToDraw
                var cityToUpdate = citiesToDraw.FirstOrDefault(c => c.cityName == oldCityName);
                if (cityToUpdate != default)
                {
                    citiesToDraw.Remove(cityToUpdate);
                    citiesToDraw.Add((oldCityName, updatedCoordinates));
                }
            }

            // Refresh the PictureBox
            pictureBox1.Invalidate();

            // Provide success feedback
            MessageBox.Show($"La ciudad '{oldCityName}' ha sido actualizada a '{newCityName}' en las coordenadas ({updatedCoordinates.X}, {updatedCoordinates.Y}).",
                            "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Clear input fields
            textBox7.Clear();
            textBox11.Clear();
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;

            // Populate ComboBoxes
            PopulateComboBox3();
            PopulateComboBox4();
            PopulateRouteComboBoxes();

            // Limpia la ruta actual si la ciudad modificada está en ella
            if (currentPath != null && (currentPath.Contains(oldCityName) || currentPath.Contains(newCityName)))
            {
                currentPath = null;
                pictureBox1.Invalidate();
            }
        }

        // Métodos para poblar los ComboBoxes
        private void PopulateComboBox3()
        {
            // Clear existing items in the ComboBox
            comboBox3.Items.Clear();

            // Add city names from the cityCoordinates dictionary
            foreach (var city in cityCoordinates.Keys)
            {
                comboBox3.Items.Add(city);
            }
        }

        private void PopulateComboBox4()
        {
            comboBox4.Items.Clear(); // Clear previous items

            foreach (var city in cityCoordinates.Keys)
            {
                comboBox4.Items.Add(city); // Add each city name to the ComboBox
            }
        }

        private void PopulateRouteComboBoxes()
        {
            comboBox1.Items.Clear(); // Clear items for "Ciudad de Inicio"
            comboBox2.Items.Clear(); // Clear items for "Ciudad donde termina"

            foreach (var city in cityCoordinates.Keys)
            {
                comboBox1.Items.Add(city);
                comboBox2.Items.Add(city);
            }
        }

        // Botón "Buscar" para encontrar la ruta (Button 7)
        private void button7_Click(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        // Botón "Ruta Alterna" (Button 8)
        private void button8_Click(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        // Métodos para manejar los cambios en los RadioButtons
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        // Botones de rutas (Button 1: Alta de ruta)
        private void button1_Click(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        // Botón "Baja de Ruta" (Button 2)
        private void button2_Click(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        // Botón "Cambio de Ruta" (Button 3)
        private void button3_Click(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        // Botón "Acerca de" (Button 9)
        private void button9_Click(object sender, EventArgs e)
        {
            // [Contenido sin cambios]
        }

        // Métodos vacíos generados automáticamente (puedes mantenerlos vacíos o eliminarlos si no los necesitas)
        private void textBox7_TextChanged(object sender, EventArgs e)
        {
        }

        private void label16_Click(object sender, EventArgs e)
        {
        }

        private void label17_Click(object sender, EventArgs e)
        {
        }

        private void label18_Click(object sender, EventArgs e)
        {
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
        }

        private void label19_Click(object sender, EventArgs e)
        {
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
        }

        private void label31_Click(object sender, EventArgs e)
        {
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }

        private void label20_Click(object sender, EventArgs e)
        {
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label21_Click(object sender, EventArgs e)
        {
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label22_Click(object sender, EventArgs e)
        {
        }

        private void label23_Click(object sender, EventArgs e)
        {
        }

        private void label24_Click(object sender, EventArgs e)
        {
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label25_Click(object sender, EventArgs e)
        {
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label26_Click(object sender, EventArgs e)
        {
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label27_Click(object sender, EventArgs e)
        {
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label30_Click(object sender, EventArgs e)
        {
        }

        private void listBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label28_Click(object sender, EventArgs e)
        {
        }

        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label29_Click(object sender, EventArgs e)
        {
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void label15_Click(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void label6_Click(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void label14_Click(object sender, EventArgs e)
        {
        }

        private void label7_Click(object sender, EventArgs e)
        {
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }

        private void label13_Click(object sender, EventArgs e)
        {
        }

        private void label8_Click(object sender, EventArgs e)
        {
        }

        private void label9_Click(object sender, EventArgs e)
        {
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
        }

        private void label12_Click(object sender, EventArgs e)
        {
        }

        private void label10_Click(object sender, EventArgs e)
        {
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
        }

        private void label11_Click(object sender, EventArgs e)
        {
        }
    }
}
